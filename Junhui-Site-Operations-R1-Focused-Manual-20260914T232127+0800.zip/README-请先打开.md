# 后台中文使用手册离线包

请先打开：

`docs/handoff/demo-owner-review-followup-r1/后台中文使用手册.md`

不要移动包内的 `docs` 或 `artifacts` 目录；手册使用相对路径引用三张当前界面截图。该目录结构已按解压后的实际路径校验。

本包只用于 Demo R2 员工操作说明，不含密码、Token、Cookie、数据库、客户资料或私有媒体。
