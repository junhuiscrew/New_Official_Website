# Test and build results

All counts below are from this run. No historical pass count was copied as a substitute for execution.

| Check | Result |
| --- | --- |
| API affected tests plus real PostgreSQL integration | PASS — 39 passed in 29.22s |
| New eight-type PostgreSQL integration test alone | PASS — 1 passed |
| Website Vitest suite | PASS — 16 files, 155 tests |
| Admin Vitest suite | PASS — 14 files, 89 tests |
| Ruff 0.12.11 on affected Python files | PASS |
| Root `pnpm lint`, including website/admin typecheck | PASS |
| `pnpm format:check` | PASS |
| Website production build after final formatting | PASS |
| Admin production build | PASS |
| `git diff --check` | PASS; only expected Git LF-to-CRLF notices were emitted |
| Final public browser run | PASS; no console or page errors |
| Six-page SEO invariance | PASS — 6/6 unchanged |

## TEST ONLY PostgreSQL matrix

The integration database was independent, migrated through `20260910_0016`, and not seeded. It used one public record for each of the eight approved types.

- Global count/page sizes: total 8, pages `3/3/2`, eight unique `(type, slug)` pairs.
- Type narrowing: technology plus manufacturing capability returned exactly 2.
- Excluded with total 0: draft translation, disabled entity, archived publication, inactive route, route noindex, non-canonical route, SEO robots noindex, wrong canonical override, disabled locale, cross-locale content, `%_`, and private Case Study client fields.
- After withdrawing technology publication and disabling manufacturing capability: total changed from 8 to 6 and neither type remained.

## Non-final failures retained for traceability

- TDD red phase failed on the three intended gaps: absent technology/capability search coverage and absent split admin status labels.
- The first PostgreSQL fixture reused one long UUID in positive and negative search needles. `pg_trgm` correctly treated them as similar, so the fixture was corrected to use independent random needles; the final test passed.
- One restricted local curl attempt could not write evidence paths or acquire the local TLS credential. The same read-only requests were rerun in the permitted local HTTPS context and passed; the failed client call was not treated as a product result.
