# Junhui Demo Search Coverage R1 Evidence

- Run ID: `20260911T100118+0800`
- Scope: `junhui-demo-r2` search coverage and Contact/RFQ admin status copy only.
- Result: the two scoped issues are closed; this package does not approve full-site SEO/GEO or production.

## Directory map

- `report/`: implementation report and structured readback.
- `coverage-before/`: six-type whitelist and baseline real Demo queries.
- `coverage-after/`: eight-type whitelist and complete real Demo API query evidence, including all cross-type pages.
- `browser-public/`: desktop/mobile search-to-detail journeys, structured output, and screenshots.
- `browser-admin/`: Contact/RFQ zh/en status readback and screenshots.
- `six-page-seo/`: frozen six-page metadata comparison plus final HTML/header captures.
- `runtime/`: redacted runtime, security, data-integrity, and migration evidence.
- `tests/`: actual test/build results and the TEST ONLY PostgreSQL contract source.
- `implementation/`: scoped changed-file list; source-level behavior is also represented by the included test sources and readback.
- `SHA256SUMS.txt`: SHA-256 for every payload file except the checksum file itself.

## Privacy boundary

This package intentionally excludes the private PostgreSQL dump, credentials, cookies, browser authentication state, environment files, private RFQ/customer content, and raw private field values. The private pre-change dump remains only in the ignored local private backup directory.

The independent PostgreSQL records described in the report and tests are marked **TEST ONLY** and were never written to the persistent Demo database.
